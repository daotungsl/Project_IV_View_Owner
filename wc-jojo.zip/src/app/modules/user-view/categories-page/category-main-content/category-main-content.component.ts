import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-main-content',
  templateUrl: './category-main-content.component.html',
  styleUrls: ['./category-main-content.component.scss']
})
export class CategoryMainContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
