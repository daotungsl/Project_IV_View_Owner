import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-page-top',
  templateUrl: './category-page-top.component.html',
  styleUrls: ['./category-page-top.component.scss']
})
export class CategoryPageTopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
