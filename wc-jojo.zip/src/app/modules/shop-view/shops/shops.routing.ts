import { Routes } from '@angular/router';
import { ShopAddComponent } from './shop-add/shop-add.component';



export const ShopRoutes: Routes = [

    // { path: '', redirectTo: 'list', pathMatch: 'prefix'},


];
