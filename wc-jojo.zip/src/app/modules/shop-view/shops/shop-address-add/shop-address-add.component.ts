import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-address-add',
  templateUrl: './shop-address-add.component.html',
  styleUrls: ['./shop-address-add.component.scss']
})
export class ShopAddressAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
