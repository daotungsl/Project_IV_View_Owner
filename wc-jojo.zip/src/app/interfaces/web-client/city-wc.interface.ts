export interface ICity{
    
         data : {
             id : number,
             name :  String ,
             description :  String ,
             created :  String ,
             updated :  String,
             status : number
        },
         message :  String ,
         status : number
    
}