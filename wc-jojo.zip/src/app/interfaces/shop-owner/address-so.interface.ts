export interface IAddressSO{
    address: String;
    description: String;
    storeId: number;
    cityId: number;

}