export interface ITypeVoucherSO{
     data : [
        {
             id : number,
             nameUnAccent: String,
             name :  String ,
             description :  String ,
             created :  String ,
             updated :  String ,
             status : number
        }
    ]
     message :  String ,
     status : number
}
