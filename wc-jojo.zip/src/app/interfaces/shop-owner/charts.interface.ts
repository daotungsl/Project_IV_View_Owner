export interface IChartsTest{
    
        labels: Array<String>,
        datasets: [
          {
            label: String,
            data: Array<number>
          }
        ]
      
}