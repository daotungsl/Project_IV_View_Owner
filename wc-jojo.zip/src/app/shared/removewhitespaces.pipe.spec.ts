import { RemovewhitespacesPipe } from './removewhitespaces.pipe';

describe('RemovewhitespacesPipe', () => {
  it('create an instance', () => {
    const pipe = new RemovewhitespacesPipe();
    expect(pipe).toBeTruthy();
  });
});
