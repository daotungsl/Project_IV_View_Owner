import { AddTimePipePipe } from './add-time-pipe.pipe';

describe('AddTimePipePipe', () => {
  it('create an instance', () => {
    const pipe = new AddTimePipePipe();
    expect(pipe).toBeTruthy();
  });
});
