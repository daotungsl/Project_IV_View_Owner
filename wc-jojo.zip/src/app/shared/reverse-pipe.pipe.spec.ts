import { ReversePipePipe } from './reverse-pipe.pipe';

describe('ReversePipePipe', () => {
  it('create an instance', () => {
    const pipe = new ReversePipePipe();
    expect(pipe).toBeTruthy();
  });
});
