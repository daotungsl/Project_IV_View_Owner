export const VI_LANG = {
  hello: 'Xin chào'
};
