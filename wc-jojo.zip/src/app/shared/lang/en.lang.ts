export const EN_LANG = {
  hello: 'Hello'
};
